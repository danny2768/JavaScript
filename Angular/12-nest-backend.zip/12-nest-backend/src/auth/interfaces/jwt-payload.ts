
export interface JwtPayload {
    id: string;
    iat?: number;
    expt?: number;
}